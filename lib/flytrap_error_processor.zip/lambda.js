import { saveErrorData, savePromiseData } from "./helpers/db.js";
import { sendWebhookNotification } from "./helpers/webhook.js";

export const handler = async (event) => {
  for (const record of event.Records) {
    const { data } = JSON.parse(record.body);

    try {
      if (data.error) {
        const { success } = await saveErrorData(data);

        if (success) {
          sendWebhookNotification();
        } else {
          console.error('Error saving error data to PostgreSQL: ', data);
        }
      } else {
        const { success } = await savePromiseData(data);

        if (success) {
          sendWebhookNotification();
        } else {
          console.error('Error saving promise data to PostgreSQL: ', data);
        }
      }
    } catch (error) {
      console.error("Error processing record:", error);
    }
  }
};