"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendWebhookNotification = void 0;
const axios_1 = __importDefault(require("axios"));
const url = process.env.WEBHOOK_ENDPOINT;
/**
 * Sends a webhook notification for a specific project.
 *
 * @param projectId - The ID of the project for which the notification is being sent.
 * @returns A promise that resolves if the request is successful, logs errors otherwise.
 */
const sendWebhookNotification = async (projectId) => {
    if (!url) {
        console.warn("Webhook endpoint URL is not defined.");
        return;
    }
    try {
        await axios_1.default.post(`${url}/api/notifications/webhook`, {
            message: "New issue",
            project_id: projectId,
        });
        console.log("Webhook notification sent successfully.");
    }
    catch (error) {
        console.error("Error sending webhook notification:", error);
    }
};
exports.sendWebhookNotification = sendWebhookNotification;
