"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.extractSourceStackFrameDetails = exports.mapStackTrace = exports.mapCodeContexts = exports.fetchSourceMap = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const source_map_1 = require("source-map");
const context_1 = require("./context");
const stream_1 = require("./stream");
// Development only
// import { readFileSync } from 'fs';
// import { join } from 'path';
// import dotenv from 'dotenv';
// dotenv.config();
const s3 = new client_s3_1.S3Client({});
const fetchSourceMap = async (projectUuid, fileName) => {
    const bucketName = process.env.S3_BUCKET_NAME;
    const key = `${projectUuid}/${fileName}`;
    try {
        // Development
        // const filePath = join(__dirname, '..', 'sourcemaps', projectUuid, fileName);
        // const sourceMapContent = readFileSync(filePath, 'utf-8');
        // return sourceMapContent;
        const command = new client_s3_1.GetObjectCommand({ Bucket: bucketName, Key: key });
        const response = await s3.send(command);
        if (response.Body) {
            return await (0, stream_1.streamToString)(response.Body);
        }
        else {
            console.warn(`No data returned from S3 for key: ${key}`);
            return null;
        }
    }
    catch (e) {
        console.error(`Error fetching source map from S3: ${e}`);
        return null;
    }
};
exports.fetchSourceMap = fetchSourceMap;
const mapCodeContexts = async (stackTrace, sourceMapContent) => {
    const consumer = await new source_map_1.SourceMapConsumer(sourceMapContent);
    const codeContexts = [];
    const stackFrames = stackTrace.split("\n");
    for (const frame of stackFrames) {
        const match = /at\s+.+\((.+):(\d+):(\d+)\)/.exec(frame);
        if (match) {
            const [, sourceFile, lineStr, columnStr] = match;
            const line = parseInt(lineStr, 10);
            const column = parseInt(columnStr, 10);
            const sourceContent = consumer.sourceContentFor(sourceFile, true);
            if (sourceContent) {
                const context = (0, context_1.extractCodeContext)(sourceContent, line);
                codeContexts.push({
                    file: sourceFile,
                    line,
                    column,
                    context,
                });
            }
            else {
                console.warn(`Source content not found for file: ${sourceFile}`);
            }
        }
    }
    consumer.destroy();
    return codeContexts;
};
exports.mapCodeContexts = mapCodeContexts;
const mapStackTrace = async (stackTrace, sourceMapContent) => {
    const consumer = await new source_map_1.SourceMapConsumer(sourceMapContent);
    const mappedStack = [];
    const stackFrames = stackTrace.split("\n");
    for (const frame of stackFrames) {
        const match = /at\s+.+\((.+):(\d+):(\d+)\)/.exec(frame);
        if (match) {
            const [, , lineNumber, columnNumber] = match;
            const original = consumer.originalPositionFor({
                line: parseInt(lineNumber, 10),
                column: parseInt(columnNumber, 10),
            });
            if (original.source) {
                mappedStack.push(`at ${original.name || "anonymous"} (${original.source}:${original.line}:${original.column})`);
            }
            else {
                mappedStack.push(frame);
            }
        }
        else {
            mappedStack.push(frame);
        }
    }
    consumer.destroy();
    return mappedStack.join("\n");
};
exports.mapStackTrace = mapStackTrace;
const extractSourceStackFrameDetails = async (sourceMapContent, line, column) => {
    const consumer = await new source_map_1.SourceMapConsumer(sourceMapContent);
    try {
        const original = consumer.originalPositionFor({
            line,
            column,
        });
        return {
            fileName: original.source || null,
            lineNumber: original.line || null,
            colNumber: original.column || null,
        };
    }
    finally {
        consumer.destroy();
    }
};
exports.extractSourceStackFrameDetails = extractSourceStackFrameDetails;
