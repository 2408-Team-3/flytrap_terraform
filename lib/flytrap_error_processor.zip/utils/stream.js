"use strict";
/**
 * Converts a readable stream into a string.
 *
 * @param stream - A readable stream (either a web `ReadableStream` or Node.js `ReadableStream`).
 * @returns A promise that resolves to the concatenated string content of the stream.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.streamToString = void 0;
const streamToString = async (stream) => {
    const chunks = [];
    for await (const chunk of stream) {
        chunks.push(Buffer.from(chunk));
    }
    return Buffer.concat(chunks).toString("utf-8");
};
exports.streamToString = streamToString;
