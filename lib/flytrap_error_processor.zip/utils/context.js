"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.extractCodeContext = void 0;
const extractCodeContext = (sourceContent, line, linesBefore = 5, linesAfter = 5) => {
    const sourceLines = sourceContent.split("\n");
    const start = Math.max(0, line - linesBefore - 1);
    const end = Math.min(sourceLines.length, line + linesAfter);
    return sourceLines.slice(start, end).join("\n");
};
exports.extractCodeContext = extractCodeContext;
