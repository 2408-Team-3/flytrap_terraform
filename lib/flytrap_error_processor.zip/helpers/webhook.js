import axios from 'axios';

export const sendWebhookNotification = async () => {
  axios.post(process.env.WEBHOOK_ENDPOINT, { data: 'New error data'});
}