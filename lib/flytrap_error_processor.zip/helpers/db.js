import { SecretsManager } from 'aws-sdk';
import { Pool } from 'pg';

const secretsManager = new SecretsManager();
const secretName = process.env.SECRET_NAME;

// Singleton pattern to reuse pool across invocations
let pool;

const getSecretValue = async () => {
  try {
    const secret = await secretsManager.getSecretValue({ SecretId: secretName }).promise();

    if (secret.SecretString) {
      return JSON.parse(secret.SecretString);
    }
    // If the secret is binary, decode and parse it
    const buff = Buffer.from(secret.SecretBinary, 'base64');
    return JSON.parse(buff.toString('ascii'));
  } catch (err) {
    console.error("Error retrieving secret:", err);
    throw err;
  }
};

const createDbPool = async () => {
  // Only create a new pool if one doesn't already exist
  if (!pool) {
    const secret = await getSecretValue();
    pool = new Pool({
      user: secret.PGUSER,
      host: process.env.PGHOST,
      database: process.env.PGDATABASE,
      password: secret.PGPASSWORD,
      port: process.env.PGPORT,
    });
  }
  return pool;
};

export const saveErrorData = async (data) => {
  try {
    const dbPool = await createDbPool();

    const project = await dbPool.query('SELECT id FROM projects WHERE pid = $1', [data.project_id]);
    const projectId = project.rows[0].id;

    const query = `INSERT INTO error_logs (name, message, created_at,
    line_number, col_number, project_id, stack_trace, handled) VALUES
    ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id`;

    const result = await dbPool.query(query, [
      data.error.name || 'UnknownError',
      data.error.message || 'No message provided',
      data.timestamp,
      data.line_number || null, // extract programmatically from stack trace
      data.col_number || null, // extract programmatically from stack trace
      projectId,
      data.error.stack || 'No stack trace available',
      data.handled,
    ]);

    return { success: true, result };
  } catch (e) {
    console.error("Error saving error data to PostgreSQL", e.message);
    return { success: false, error: e.message };
  }
};

export const savePromiseData = async (data) => {
  try {
    const dbPool = await createDbPool();
    const query = `INSERT INTO rejection_logs (value, created_at,
    project_id, handled) VALUES ($1, $2, $3, $4) RETURNING id`;

    const result = await dbPool.query(query, [
      data.value,
      data.timestamp,
      data.project_id,
      data.handled,
    ]);

    return { success: true, result };
  } catch (e) {
    console.error("Error saving promise data to PostgreSQL", e.message);
    return { success: false, error: e.message };
  }
};