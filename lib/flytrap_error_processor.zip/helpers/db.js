import pgPkg from 'pg';
const { Pool } = pgPkg;

// Singleton pattern to reuse pool across invocations
let pool;

const createDbPool = async () => {
  // Only create a new pool if one doesn't already exist
  if (!pool) {
    pool = new Pool({
      user: process.env.PGUSER,
      host: process.env.PGHOST,
      database: process.env.PGDATABASE,
      password: process.env.PGPASSWORD,
      port: process.env.PGPORT,
      ssl: { rejectUnauthorized: false },
    });
  }
  return pool;
};

export const saveErrorData = async (data) => {
  try {
    const dbPool = await createDbPool();

    const project = await dbPool.query('SELECT id FROM projects WHERE uuid = $1', [data.project_id]);
    const projectId = project.rows[0].id;

      //const error_uuid = uuidv4(); deprecation warning?
      const error_uuid = '75442486-0878-440c-9db1-a7006c25a39e'

    const query = `INSERT INTO error_logs (uuid, name, message, created_at,
    line_number, col_number, project_id, stack_trace, handled) VALUES
    ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING id`;

    const result = await dbPool.query(query, [
      error_uuid,
      data.error.name || 'UnknownError',
      data.error.message || 'No message provided',
      data.timestamp,
      data.line_number || null, // extract programmatically from stack trace
      data.col_number || null, // extract programmatically from stack trace
      projectId,
      data.error.stack || 'No stack trace available',
      data.handled,
    ]);

    return { success: true, result };
  } catch (e) {
    console.error("Error saving error data to PostgreSQL", e.message);
    return { success: false, error: e.message };
  }
};

export const savePromiseData = async (data) => {
  try {
    const dbPool = await createDbPool();
    const query = `INSERT INTO rejection_logs (value, created_at,
    project_id, handled) VALUES ($1, $2, $3, $4) RETURNING id`;

    const result = await dbPool.query(query, [
      data.value,
      data.timestamp,
      data.project_id,
      data.handled,
    ]);

    return { success: true, result };
  } catch (e) {
    console.error("Error saving promise data to PostgreSQL", e.message);
    return { success: false, error: e.message };
  }
};