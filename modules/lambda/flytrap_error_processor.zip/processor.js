"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const database_1 = require("./utils/database");
const webhook_1 = require("./utils/webhook");
/**
 * AWS Lambda handler to process event records, save error or rejection data to PostgreSQL,
 * and send webhook notifications if successful.
 *
 * @param event - The event object containing an array of records.
 */
const handler = async (event) => {
    for (const record of event.Records) {
        const { data } = JSON.parse(record.body);
        if (data.codeContexts) {
            data.codeContexts = data.codeContexts.map((contextEntry) => ({
                ...contextEntry,
                context: JSON.parse(contextEntry.context),
            }));
        }
        try {
            if (data.error) {
                // Save error data to PostgreSQL and send webhook notification on success.
                const { success } = await (0, database_1.saveErrorData)(data);
                if (success) {
                    (0, webhook_1.sendWebhookNotification)(data.project_id); // fire-and-forget
                }
                else {
                    console.error("Error saving error data to PostgreSQL");
                }
            }
            else {
                // Save rejection data to PostgreSQL and send webhook notification on success.
                const { success } = await (0, database_1.saveRejectionData)(data);
                if (success) {
                    (0, webhook_1.sendWebhookNotification)(data.project_id); // fire-and-forget
                }
                else {
                    console.error("Error saving rejection data to PostgreSQL");
                }
            }
        }
        catch (e) {
            // Log unexpected errors during processing.
            console.error("Error processing record:", e);
        }
    }
};
exports.handler = handler;
