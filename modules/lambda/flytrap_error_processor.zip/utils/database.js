"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveRejectionData = exports.saveErrorData = void 0;
const pg_1 = __importDefault(require("pg"));
const crypto_1 = __importDefault(require("crypto"));
const uuid_1 = require("uuid");
const stacktrace_1 = require("./stacktrace");
const environment = process.env.NODE_ENV || 'development';
if (environment === 'development') {
    Promise.resolve().then(() => __importStar(require('dotenv'))).then((dotenv) => dotenv.config());
}
const { Pool } = pg_1.default;
const pool = new Pool({
    user: process.env.PGUSER,
    host: process.env.PGUSERHOST,
    database: process.env.PGDATABASE,
    password: process.env.PGPASSWORD,
    port: Number(process.env.PGPORT),
    ssl: environment === 'production' ? { rejectUnauthorized: false } : false,
});
/**
 * Saves error data to the database, processes stack trace details, and generates a unique hash for the error.
 *
 * @param data - The error data containing details like stack trace, method, and context.
 * @returns A promise that resolves to a success flag with query result or error.
 */
const saveErrorData = async (data) => {
    try {
        // Retrieve project ID and platform.
        const project = await pool.query("SELECT id, platform FROM projects WHERE uuid = $1", [data.project_id]);
        const projectId = project.rows[0].id ? project.rows[0].id : null;
        if (!projectId)
            return { success: false, error: "Project not found." };
        const projectPlatform = project.rows[0].platform;
        const error_uuid = (0, uuid_1.v4)();
        // Process stack trace and extract source details.
        const { fileName, lineNumber, colNumber, updatedStack, updatedContexts } = await (0, stacktrace_1.processStackTrace)(data, projectPlatform);
        const codeContextsJson = JSON.stringify(updatedContexts);
        // Generate a unique hash for the error.
        const hashInput = `${fileName}:${lineNumber}:${colNumber}:${data.error.name}`;
        const errorHash = crypto_1.default
            .createHash("sha256")
            .update(hashInput)
            .digest("hex");
        // Generate a unique hash for the ip address.
        const ipHash = crypto_1.default
            .createHash("sha256")
            .update(data.ip || "")
            .digest("hex");
        // Insert error data into the database.
        const query = `INSERT INTO error_logs (uuid, name, message, created_at, filename,
    line_number, col_number, project_id, stack_trace, handled, contexts, method, path, ip, os, browser, runtime, error_hash) VALUES 
    ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18) RETURNING id`;
        const result = await pool.query(query, [
            error_uuid,
            data.error.name || "UnknownError",
            data.error.message || "No message provided",
            data.timestamp,
            fileName,
            lineNumber,
            colNumber,
            projectId,
            updatedStack || "No stack trace available",
            data.handled,
            codeContextsJson,
            data.method,
            data.path,
            ipHash,
            data.os,
            data.browser,
            data.runtime,
            errorHash,
        ]);
        return { success: true, result };
    }
    catch (e) {
        console.error("Error saving error data to PostgreSQL", e);
        return { success: false, error: e };
    }
};
exports.saveErrorData = saveErrorData;
/**
 * Saves rejection data to the database.
 *
 * @param data - The rejection data containing details like value and method.
 * @returns A promise that resolves to a success flag with query result or error.
 */
const saveRejectionData = async (data) => {
    try {
        // Retrieve project ID.
        const project = await pool.query("SELECT id FROM projects WHERE uuid = $1", [data.project_id]);
        const projectId = project.rows[0].id ? project.rows[0].id : null;
        if (!projectId)
            return { success: false, error: "Project not found." };
        const rejection_uuid = (0, uuid_1.v4)();
        // Generate a unique hash for the ip address.
        const ipHash = crypto_1.default
            .createHash("sha256")
            .update(data.ip || "")
            .digest("hex");
        // Insert rejection data into the database.
        const query = `INSERT INTO rejection_logs (uuid, value, created_at,
    project_id, handled, method, path, ip, os, browser, runtime) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) RETURNING id`;
        const result = await pool.query(query, [
            rejection_uuid,
            data.value,
            data.timestamp,
            projectId,
            data.handled,
            data.method,
            data.path,
            ipHash,
            data.os,
            data.browser,
            data.runtime,
        ]);
        return { success: true, result };
    }
    catch (e) {
        console.error("Error saving promise data to PostgreSQL", e);
        return { success: false, error: e };
    }
};
exports.saveRejectionData = saveRejectionData;
