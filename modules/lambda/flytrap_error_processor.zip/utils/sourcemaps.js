"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.extractSourceStackFrameDetails = exports.mapStackTrace = exports.mapCodeContexts = exports.fetchSourceMap = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const source_map_1 = require("source-map");
const context_1 = require("./context");
const stream_1 = require("./stream");
const environment = process.env.NODE_ENV || 'development';
if (environment === 'development') {
    Promise.resolve().then(() => __importStar(require('dotenv'))).then((dotenv) => dotenv.config());
}
const s3 = new client_s3_1.S3Client({
    region: process.env.REGION,
});
/**
 * Fetches a source map from an S3 bucket for a given project and file name.
 *
 * @param projectUuid - The unique identifier for the project.
 * @param fileName - The name of the source map file.
 * @returns A promise that resolves to the source map content or null if not found.
 */
const fetchSourceMap = async (projectUuid, fileName) => {
    try {
        if (environment === "development") {
            const { readFileSync } = await Promise.resolve().then(() => __importStar(require("fs")));
            const { join } = await Promise.resolve().then(() => __importStar(require("path")));
            const filePath = join(__dirname, '..', 'sourcemaps', projectUuid, fileName);
            const sourceMapContent = readFileSync(filePath, 'utf-8');
            return sourceMapContent;
        }
        const bucketName = process.env.S3_BUCKET_NAME;
        const key = `${projectUuid}/${fileName}`;
        const command = new client_s3_1.GetObjectCommand({ Bucket: bucketName, Key: key });
        const response = await s3.send(command);
        if (response.Body) {
            const content = await (0, stream_1.streamToString)(response.Body);
            return content;
        }
        else {
            console.error(`No data returned from S3 for key: ${key}`);
            return null;
        }
    }
    catch (e) {
        console.error(`Error fetching source map from S3: ${e}`);
        return null;
    }
};
exports.fetchSourceMap = fetchSourceMap;
/**
 * Maps stack trace entries to corresponding code contexts using a source map.
 *
 * @param stackTrace - The stack trace to map.
 * @param sourceMapContent - The source map content for mapping.
 * @returns A promise that resolves to an array of code contexts.
 */
const mapCodeContexts = async (stackTrace, sourceMapContent) => {
    const consumer = await new source_map_1.SourceMapConsumer(sourceMapContent);
    const codeContexts = [];
    const stackFrames = stackTrace.split("\n");
    for (const frame of stackFrames) {
        const match = /at\s+.+\((.+):(\d+):(\d+)\)/.exec(frame);
        if (match) {
            const [, sourceFile, lineStr, columnStr] = match;
            const line = parseInt(lineStr, 10);
            const column = parseInt(columnStr, 10);
            const sourceContent = consumer.sourceContentFor(sourceFile, true);
            if (sourceContent) {
                const context = (0, context_1.extractCodeContext)(sourceContent, line);
                codeContexts.push({
                    file: sourceFile,
                    line,
                    column,
                    context,
                });
            }
            else {
                console.warn(`Source content not found for file: ${sourceFile}`);
            }
        }
    }
    consumer.destroy();
    return codeContexts;
};
exports.mapCodeContexts = mapCodeContexts;
/**
 * Maps a minified stack trace to its original source positions using a source map.
 *
 * @param stackTrace - The stack trace to map.
 * @param sourceMapContent - The source map content for mapping.
 * @returns A promise that resolves to the mapped stack trace.
 */
const mapStackTrace = async (stackTrace, sourceMapContent) => {
    const consumer = await new source_map_1.SourceMapConsumer(sourceMapContent);
    const mappedStack = [];
    const stackFrames = stackTrace.split("\n");
    for (const frame of stackFrames) {
        const match = /at\s+.+\((.+):(\d+):(\d+)\)/.exec(frame);
        if (match) {
            const [, , lineNumber, columnNumber] = match;
            const original = consumer.originalPositionFor({
                line: parseInt(lineNumber, 10),
                column: parseInt(columnNumber, 10),
            });
            if (original.source) {
                mappedStack.push(`at ${original.name || "anonymous"} (${original.source}:${original.line}:${original.column})`);
            }
            else {
                mappedStack.push(frame);
            }
        }
        else {
            mappedStack.push(frame);
        }
    }
    consumer.destroy();
    return mappedStack.join("\n");
};
exports.mapStackTrace = mapStackTrace;
/**
 * Extracts original stack frame details from a source map.
 *
 * @param sourceMapContent - The source map content.
 * @param line - The minified source line number.
 * @param column - The minified source column number.
 * @returns A promise that resolves to the original stack frame details.
 */
const extractSourceStackFrameDetails = async (sourceMapContent, line, column) => {
    const consumer = await new source_map_1.SourceMapConsumer(sourceMapContent);
    try {
        const original = consumer.originalPositionFor({
            line,
            column,
        });
        return {
            fileName: original.source || null,
            lineNumber: original.line || null,
            colNumber: original.column || null,
        };
    }
    finally {
        consumer.destroy();
    }
};
exports.extractSourceStackFrameDetails = extractSourceStackFrameDetails;
